// Clase Producto
class Producto {
    constructor(nombre, categoria, precio, stock){
        this.nombre = nombre
        this.categoria = categoria
        this.precio = precio
        this.stock = stock
    }
}
