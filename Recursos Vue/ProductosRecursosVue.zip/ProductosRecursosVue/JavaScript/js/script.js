// Arrays para productos y carrito
const productos = []
const carrito = []

// Elementos del DOM
const nombreInput = document.getElementById("nombre")
const categoriaInput = document.getElementById("categoria")
const precioInput = document.getElementById("precio")
const stockInput = document.getElementById("stock")
const btnAgregar = document.getElementById("btnAgregar")
const mensajeError = document.getElementById("mensajeError")

const productosLista = document.getElementById("productosLista")
const carritoLista = document.getElementById("carritoLista")

// Función para agregar producto
btnAgregar.addEventListener("click", () => {
    mensajeError.textContent = ""

    const nombre = nombreInput.value.trim()
    const categoria = categoriaInput.value.trim()
    const precio = Number(precioInput.value)
    const stock = Number(stockInput.value)

    // Validaciones
    if(!nombre || !categoria){
        mensajeError.textContent = "Nombre y categoría no pueden estar vacíos."
        return
    }
    if(precio < 0 || stock < 0){
        mensajeError.textContent = "Precio y stock deben ser mayores o iguales a 0."
        return
    }

    // Crear producto y agregar al array
    const producto = new Producto(nombre, categoria, precio, stock)
    productos.push(producto)

    // Actualizar la lista
    mostrarProductos()
    limpiarFormulario()
})

// Mostrar productos en pantalla
function mostrarProductos(){
    productosLista.innerHTML = ""

    productos.forEach(p => {
        const div = document.createElement("div")
        div.className = "producto-card"
        div.innerHTML = `
            <strong>${p.nombre}</strong><br>
            Categoría: ${p.categoria}<br>
            Precio: €${p.precio}<br>
            Stock: ${p.stock}<br>
        `

        const btnCarrito = document.createElement("button")
        btnCarrito.textContent = carrito.includes(p) ? "Quitar del carrito" : "Añadir al carrito"
        btnCarrito.addEventListener("click", () => toggleCarrito(p))

        div.appendChild(btnCarrito)
        productosLista.appendChild(div)
    })

    mostrarCarrito()
}

// Agregar o quitar del carrito
function toggleCarrito(producto){
    if(carrito.includes(producto)){
        const index = carrito.indexOf(producto)
        carrito.splice(index, 1)
    } else {
        carrito.push(producto)
    }
    mostrarProductos()
}

// Mostrar carrito
function mostrarCarrito(){
    carritoLista.innerHTML = ""
    carrito.forEach(p => {
        const div = document.createElement("div")
        div.className = "carrito-card"
        div.textContent = `${p.nombre} - €${p.precio} - Stock: ${p.stock}`
        carritoLista.appendChild(div)
    })
}

// Limpiar formulario
function limpiarFormulario(){
    nombreInput.value = ""
    categoriaInput.value = ""
    precioInput.value = ""
    stockInput.value = ""
}
