import { defineStore } from 'pinia'
import axios from 'axios'
import { ref, computed } from 'vue'

export const useProductosStore = defineStore('productos', () => {

    // =================
    // STATE
    // =================
    const productos = ref([])
    const categorias = ref([])
    const usuarios = ref([])
    const cargado = ref(false)

    const usuarioActivo = ref(null)
    const carrito = ref([])

    // =================
    // ACTIONS
    // =================
    async function cargarDatos() {
        if (cargado.value) return

        try {
            const res = await axios.get('/data/db.json')

            productos.value = res.data.productos.map(p => ({
                ...p,
                categoria:
                    res.data.categorias.find(c => c.id === p.categoriaId)?.nombre
                    || 'Desconocido'
            }))

            categorias.value = res.data.categorias
            usuarios.value = res.data.usuarios

            cargado.value = true

        } catch (error) {
            console.error('Error cargando datos', error)
        }
    }

    function getProductoById(id) {
        return productos.value.find(p => p.id == id)
    }

    // =================
    // LOGIN
    // =================
    function getUsuarioByEmail(email) {
        return usuarios.value.find(u => u.email === email)
    }

    // =================
    // CARRITO
    // =================

    function anadirAlCarrito(id) {
        if (!carrito.value.includes(id)) {
            carrito.value.push(id)
        }
    }

    function quitarDelCarrito(id) {
        carrito.value = carrito.value.filter(c => c !== id)
    }

    function toggleCarrito(id) {
        if (estaEnCarrito(id)) {
            quitarDelCarrito(id)
        } else {
            anadirAlCarrito(id)
        }
    }

    function estaEnCarrito(id) {
        return carrito.value.includes(id)
    }

    // =================
    // COMPUTED
    // =================
    const categoriasUnicas = computed(() =>
        [...new Set(categorias.value.map(c => c.nombre))]
    )

    return {
        productos,
        categorias,
        usuarios,
        cargado,
        usuarioActivo,
        carrito,
        cargarDatos,
        getProductoById,
        getUsuarioByEmail,

        // carrito
        anadirAlCarrito,
        quitarDelCarrito,
        toggleCarrito,
        estaEnCarrito,

        categoriasUnicas
    }
})
