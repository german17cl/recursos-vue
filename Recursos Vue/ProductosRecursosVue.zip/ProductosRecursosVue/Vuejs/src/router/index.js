import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import ProductosView from '../views/ProductosView.vue'
import LoginView from '../views/LoginView.vue'
import ProductosDetalleView from '../views/ProductosDetalleView.vue'
import CarritoView from '../views/CarritoView.vue'
import { useProductosStore } from '../stores/useProductosStore.js'

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/productos',
    name: 'productos',
    component: ProductosView
  },
  {
    path: '/productos/:id',
    name: 'productoDetalle',
    component: ProductosDetalleView
  },
  {
    path: '/login',
    name: 'login',
    component: LoginView
  },
  {
    path: '/carrito',
    name: 'carrito',
    component: CarritoView,
    meta: { requiresAuth: true }
  }
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
})

router.beforeEach((to, from, next) => {
  const store = useProductosStore()

  if (to.meta.requiresAuth && !store.usuarioActivo) {
    next('/login')
  } else {
    next()
  }
})

export default router
