<script setup>
import { RouterView, RouterLink } from 'vue-router'
import { useProductosStore } from './stores/useProductosStore.js'

const store = useProductosStore()

function logout() {
  store.usuarioActivo = null
  store.carrito = [] // opcional: vaciar carrito al cerrar sesión
}
</script>

<template>
  <div id="app">

    <!-- HEADER -->
    <header>
      <nav class="navbar">
        <div class="container">

          <!-- Logo -->
          <div class="nav-brand">
            <h1>🛒 ShopClub</h1>
            <p>Gestión de Productos y Carrito</p>
          </div>

          <!-- NAV -->
          <div class="nav-links">
            <RouterLink to="/">Inicio</RouterLink>
            <RouterLink to="/productos">Productos</RouterLink>

            <!-- NO logueado -->
            <RouterLink v-if="!store.usuarioActivo" to="/login">
              Login
            </RouterLink>

            <!-- Logueado -->
            <template v-else>
              <span class="usuario-nombre">
                Hola, {{ store.usuarioActivo.nombre }}
              </span>

              <RouterLink to="/carrito">
                Carrito ({{ store.carrito.length }})
              </RouterLink>

              <button @click="logout" class="btn-logout">
                Cerrar sesión
              </button>
            </template>
          </div>

        </div>
      </nav>
    </header>

    <!-- CONTENIDO -->
    <main class="container">
      <RouterView />
    </main>

    <!-- FOOTER -->
    <footer>
      <div class="container">
        <p>&copy; 2026 ShopClub - Portal de Usuarios</p>
      </div>
    </footer>

  </div>
</template>

<style>
#app {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

main {
  flex: 1;
  padding: 2rem 1.5rem;
}

/* Navbar */
.navbar {
  background-color: #1e3c72;
  color: white;
  padding: 1rem 0;
}

.navbar .container {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.nav-links {
  display: flex;
  gap: 1rem;
  align-items: center;
}

.nav-links a {
  color: white;
  text-decoration: none;
  font-weight: 500;
}

.nav-links a:hover {
  text-decoration: underline;
}

.usuario-nombre {
  margin-right: 1rem;
  font-weight: 600;
}

.btn-logout {
  background: #e74c3c;
  color: white;
  border: none;
  padding: 0.4rem 0.8rem;
  border-radius: 4px;
  cursor: pointer;
}

.btn-logout:hover {
  background: #c0392b;
}

/* Footer */
footer {
  background: #f1f1f1;
  padding: 1rem 0;
  text-align: center;
  font-size: 0.9rem;
  color: #555;
}
</style>
