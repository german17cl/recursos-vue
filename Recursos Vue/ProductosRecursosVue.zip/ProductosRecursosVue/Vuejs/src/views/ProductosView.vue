<template>
    <div class="productos-view">
        <h1>Catálogo de Productos</h1>

        <!-- FILTROS -->
        <div class="filtros" v-if="store.cargado">
            <!-- Buscar por nombre -->
            <input type="text" v-model="filtroNombre" placeholder="Buscar por nombre..." />

            <!-- Filtrar por categoría -->
            <select v-model="filtroCategoria">
                <option value="">Todas las categorías</option>
                <option v-for="c in categoriasUnicas" :key="c" :value="c">
                    {{ c }}
                </option>
            </select>

            <!-- Filtrar por stock -->
            <input type="number" v-model.number="stockMin" placeholder="Stock mínimo" min="0" />
            <input type="number" v-model.number="stockMax" placeholder="Stock máximo" :max="stockMaxTotal" />

            <!-- Filtrar por precio (barra de progreso) -->
            <div class="filtro-precio">
                <label>Precio: {{ filtroPrecioMin }} € - {{ filtroPrecioMax }} €</label>
                <input type="range" :min="precioMin" :max="precioMax" v-model.number="filtroPrecioMin" />
                <input type="range" :min="precioMin" :max="precioMax" v-model.number="filtroPrecioMax" />
            </div>
        </div>

        <!-- LISTA DE PRODUCTOS -->
        <div class="productos-lista" v-if="store.cargado">
            <div class="producto-card" v-for="producto in productosFiltrados" :key="producto.id">
                <img :src="`/images/${producto.imagen}`" :alt="producto.nombre" />
                <h3>{{ producto.nombre }}</h3>
                <p><strong>Categoría:</strong> {{ producto.categoria }}</p>
                <p><strong>Precio:</strong> {{ producto.precio }} €</p>
                <p><strong>Stock:</strong> {{ producto.stock }}</p>

                <button @click="verDetalle(producto.id)">Ver detalle</button>

                <button v-if="store.usuarioActivo" @click="toggleCarrito(producto.id)">
                    {{ store.estaEnCarrito(producto.id) ? "Quitar del carrito" : "Añadir al carrito" }}
                </button>

                <p v-else>
                    Debes <router-link to="/login">iniciar sesión</router-link> para añadir al carrito
                </p>
            </div>
        </div>

        <p v-else>Cargando productos...</p>
    </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useProductosStore } from '../stores/useProductosStore.js'

const store = useProductosStore()
const router = useRouter()

// FILTROS
const filtroNombre = ref('')
const filtroCategoria = ref('')
const stockMin = ref(0)
const stockMax = ref(0)
const filtroPrecioMin = ref(0)
const filtroPrecioMax = ref(0)

// Rango total para precios y stock
const precioMin = ref(0)
const precioMax = ref(0)
const stockMaxTotal = ref(0)

// Cargar productos
onMounted(async () => {
    await store.cargarDatos()

    if (store.productos.length) {
        // Rango de precios
        precioMin.value = Math.min(...store.productos.map(p => p.precio))
        precioMax.value = Math.max(...store.productos.map(p => p.precio))
        filtroPrecioMin.value = precioMin.value
        filtroPrecioMax.value = precioMax.value

        // Rango de stock
        stockMaxTotal.value = Math.max(...store.productos.map(p => p.stock))
        stockMax.value = stockMaxTotal.value
    }
})

// Filtrado combinado
const productosFiltrados = computed(() => {
    if (!store.cargado) return []

    return store.productos
        .filter(p => p.nombre.toLowerCase().includes(filtroNombre.value.toLowerCase()))
        .filter(p => filtroCategoria.value ? p.categoria === filtroCategoria.value : true)
        .filter(p => p.stock >= stockMin.value && p.stock <= stockMax.value)
        .filter(p => p.precio >= filtroPrecioMin.value && p.precio <= filtroPrecioMax.value)
})

// Categorías únicas
const categoriasUnicas = computed(() => [...new Set(store.productos.map(p => p.categoria))])

// Funciones
function verDetalle(id) {
    router.push(`/productos/${id}`)
}

function toggleCarrito(id) {
    store.toggleCarrito(id)
}
</script>

<style scoped>
.productos-view {
    padding: 2rem 0;
}

.filtros {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.filtros input,
.filtros select {
    padding: 0.5rem;
    font-size: 1rem;
    min-width: 150px;
}

/* Slider de precio */
.filtro-precio {
    display: flex;
    flex-direction: column;
    gap: 0.2rem;
}

.productos-lista {
    display: flex;
    flex-wrap: wrap;
    gap: 1.5rem;
}

.producto-card {
    background: #f8f8f8;
    padding: 1rem;
    border-radius: 8px;
    text-align: center;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.producto-card img {
    width: 100%;
    height: 250px;
    object-fit: cover;
    border-radius: 6px;
}

.producto-card button {
    margin-top: 0.5rem;
    padding: 0.5rem;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.producto-card button:first-of-type {
    background: #1e3c72;
    color: white;
}

.producto-card button:last-of-type {
    background: #e74c3c;
    color: white;
}

.producto-card button:hover {
    opacity: 0.9;
}
</style>
