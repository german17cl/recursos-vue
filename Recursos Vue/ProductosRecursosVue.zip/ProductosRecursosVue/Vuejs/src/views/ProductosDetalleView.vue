<template>
    <div class="producto-detalle-view" v-if="producto">
        <button class="btn-volver" @click="volver">
            ← Volver al catálogo
        </button>

        <div class="detalle-card">
            <img :src="'/images/' + producto.imagen" :alt="producto.nombre" />

            <div class="info">
                <h2>{{ producto.nombre }}</h2>

                <p><strong>Categoría:</strong> {{ producto.categoria }}</p>
                <p><strong>Precio:</strong> {{ producto.precio }} €</p>
                <p><strong>Descripción:</strong> {{ producto.descripcion }}</p>

                <div v-if="store.usuarioActivo">
                    <button v-if="!store.estaEnCarrito(producto.id)" @click="store.anadirAlCarrito(producto.id)"
                        class="btn-carrito">
                        🛒 Añadir al carrito
                    </button>

                    <button v-else @click="store.quitarDelCarrito(producto.id)" class="btn-quitar">
                        ❌ Quitar del carrito
                    </button>
                </div>

                <p v-else class="login-msg">
                    Debes
                    <router-link to="/login">iniciar sesión</router-link>
                    para añadir productos al carrito
                </p>
            </div>
        </div>
    </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useProductosStore } from '../stores/useProductosStore.js'

const store = useProductosStore()
const route = useRoute()
const router = useRouter()

const producto = ref(null)

onMounted(async () => {
    await store.cargarDatos()
    producto.value = store.getProductoById(route.params.id)
})

function volver() {
    router.push('/productos')
}
</script>


<style scoped>
.producto-detalle-view {
    padding: 2rem 0;
}

.btn-volver {
    background: #1e3c72;
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    cursor: pointer;
    margin-bottom: 1rem;
}

.detalle-card {
    display: flex;
    gap: 2rem;
    flex-wrap: wrap;
    background: #f8f8f8;
    padding: 1.5rem;
    border-radius: 8px;
}

.detalle-card img {
    max-width: 400px;
    width: 100%;
    border-radius: 6px;
    object-fit: cover;
}

.info {
    flex: 1;
}

.info h2 {
    margin-top: 0;
    color: #1e3c72;
}

.btn-carrito {
    margin-top: 1rem;
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    background: #27ae60;
    color: white;
}

.btn-quitar {
    margin-top: 1rem;
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    background: #e74c3c;
    color: white;
}

.login-msg {
    margin-top: 1rem;
    color: #555;
}
</style>
