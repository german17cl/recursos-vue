<template>
    <div class="carrito-view">
        <h2>🛒 Mi Carrito</h2>

        <!-- Carrito vacío -->
        <div v-if="productosCarrito.length === 0" class="carrito-vacio">
            <p>No tienes productos en el carrito.</p>
            <RouterLink to="/productos" class="btn-volver">
                Ir a productos
            </RouterLink>
        </div>

        <!-- Lista de productos -->
        <div v-else class="carrito-contenido">

            <div v-for="producto in productosCarrito" :key="producto.id" class="producto-card">
                <img :src="'/images/' + producto.imagen" :alt="producto.nombre" />

                <div class="info">
                    <h3>{{ producto.nombre }}</h3>
                    <p>{{ producto.categoria }}</p>
                    <p class="precio">{{ producto.precio }} €</p>

                    <button @click="quitar(producto.id)">
                        ❌ Quitar del carrito
                    </button>
                </div>
            </div>

            <!-- Total -->
            <div class="carrito-total">
                <h3>Total: {{ totalCarrito }} €</h3>
                <button class="btn-comprar">
                    Finalizar compra
                </button>
            </div>

        </div>
    </div>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { useProductosStore } from '../stores/useProductosStore.js'

const store = useProductosStore()

onMounted(() => {
    store.cargarDatos()
})

// Productos que están en el carrito
const productosCarrito = computed(() =>
    store.productos.filter(p =>
        store.carrito.includes(p.id)
    )
)

// Total del carrito
const totalCarrito = computed(() =>
    productosCarrito.value.reduce(
        (total, p) => total + p.precio,
        0
    )
)

function quitar(id) {
    store.quitarDelCarrito(id)
}
</script>

<style scoped>
.carrito-view {
    padding: 2rem 0;
}

.carrito-vacio {
    text-align: center;
    margin-top: 2rem;
}

.btn-volver {
    display: inline-block;
    margin-top: 1rem;
    background: #1e3c72;
    color: white;
    padding: 0.5rem 1rem;
    border-radius: 4px;
    text-decoration: none;
}

.carrito-contenido {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.producto-card {
    display: flex;
    gap: 1.5rem;
    background: #f8f8f8;
    padding: 1rem;
    border-radius: 8px;
}

.producto-card img {
    width: 120px;
    border-radius: 6px;
    object-fit: cover;
}

.info {
    flex: 1;
}

.precio {
    font-weight: bold;
    color: #27ae60;
}

button {
    margin-top: 0.5rem;
    background: #e74c3c;
    color: white;
    border: none;
    padding: 0.4rem 0.8rem;
    border-radius: 4px;
    cursor: pointer;
}

.carrito-total {
    margin-top: 2rem;
    text-align: right;
    background: #eee;
    padding: 1rem;
    border-radius: 6px;
}

.btn-comprar {
    background: #27ae60;
    margin-top: 0.5rem;
}
</style>
