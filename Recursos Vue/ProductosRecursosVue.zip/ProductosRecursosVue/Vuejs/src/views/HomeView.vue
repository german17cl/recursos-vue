<template>
  <div class="home">
    <div class="header-section">
      <div class="company-info">
        <h1>ShopClub</h1>
        <p class="subtitle">Portal de Gestión de Productos</p>
      </div>
    </div>

    <div class="content-grid" v-if="store.cargado">
      <div class="main-info">
        <h2>Bienvenido al ShopClub</h2>
        <p>
          Explora nuestro catálogo de productos, añade artículos a tu carrito
          y gestiona tus compras fácilmente desde cualquier dispositivo.
        </p>

        <div class="quick-stats">
          <div class="stat">
            <span class="number">{{ store.productos.length }}</span>
            <span class="label">Productos</span>
          </div>

          <div class="stat">
            <span class="number">{{ store.categorias.length }}</span>
            <span class="label">Categorías</span>
          </div>

          <div class="stat">
            <span class="number">{{ store.usuarios.length }}</span>
            <span class="label">Usuarios</span>
          </div>
        </div>
      </div>

      <div class="features">
        <h3>Funcionalidades</h3>
        <ul>
          <li>🛒 Catálogo completo de productos</li>
          <li>🔍 Búsqueda y filtrado por categoría</li>
          <li>➕ Añadir productos al carrito</li>
          <li>👤 Gestión de tu carrito personal</li>
        </ul>
      </div>
    </div>

    <p v-else>Cargando datos...</p>

    <div class="info-banner">
      <p>
        Compra fácilmente • Gestiona tu carrito • Accede a todas las categorías
      </p>
    </div>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useProductosStore } from '../stores/useProductosStore.js'

const store = useProductosStore()

// ⚠️ imprescindible
onMounted(async () => {
  await store.cargarDatos()
})
</script>
