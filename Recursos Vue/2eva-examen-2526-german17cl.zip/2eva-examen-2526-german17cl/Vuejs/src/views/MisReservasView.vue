<script setup>
import { useAppStore } from '../stores/useAppStore'

const store = useAppStore()


    function cancelarReserva(index) {
        const confirmar = confirm('¿Seguro que quieres cancelar esta reserva?')

        if (confirmar) {
            store.reservas.splice(index, 1)
        }
    }
</script>

<template>
    <div class="reservas-container">

        <h1>Mis Reservas</h1>
        <p class="subtitulo">Gestiona tus reservas de vehículos</p>

        <div v-if="store.reservas.length === 0" class="empty">
        No tienes reservas aún
        </div>

        <div v-for="(r, i) in store.reservas" :key="i" class="reserva-card">

        <!-- HEADER -->
        <div class="reserva-header">
            <h2>{{ r.vehiculo.marca }} {{ r.vehiculo.modelo }}</h2>
            <span class="tipo">{{ r.vehiculo.tipo }}</span>
        </div>

        <!-- INFO -->
        <div class="reserva-info">

            <div class="bloque">
            <h4>Fecha</h4>
            <p>{{ r.fecha }}</p>
            </div>

            <div class="bloque">
            <h4>Propósito</h4>
            <p>{{ r.motivo }}</p>
            </div>

            <div class="bloque">
            <h4>Creada</h4>
            <p>{{ new Date().toLocaleString() }}</p>
            </div>

        </div>

        <!-- ACCIÓN -->
        <button class="btn-cancelar" @click="cancelarReserva(i)">
            Cancelar reserva
        </button>

        </div>

    </div>
</template>

<style setup>
.reservas-container {
  padding: 20px;
  max-width: 800px;
  margin: auto;
}

.subtitulo {
  color: #666;
  margin-bottom: 20px;
}

/* CARD */
.reserva-card {
  background: white;
  border-radius: 14px;
  padding: 15px;
  margin-bottom: 15px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.08);
}

/* HEADER */
.reserva-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.reserva-header h2 {
  font-size: 1.2rem;
}

/* TAG TIPO */
.tipo {
  background: #f0f2ff;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 0.8rem;
}

/* INFO GRID */
    .reserva-info {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
    margin: 10px 0;
    }

    .bloque h4 {
    font-size: 0.8rem;
    color: #777;
    margin-bottom: 4px;
    }

    .bloque p {
    font-weight: 500;
    }

    /* BOTÓN CANCELAR */
    .btn-cancelar {
    background: #ffe6e6;
    color: #b30000;
    border: 1px solid #ffb3b3;
    padding: 6px 12px;
    border-radius: 8px;
    cursor: pointer;
    transition: 0.2s;
    }

    .btn-cancelar:hover {
    background: #ffcccc;
    }

    /* EMPTY STATE */
    .empty {
    text-align: center;
    color: #888;
    padding: 30px;
    }
</style>
