<script setup>
import { useRoute, useRouter } from 'vue-router'
import { useVehiculosStore } from '../stores/useVehiculosStore'
import { useAppStore } from '../stores/useAppStore'
import { ref, onMounted } from 'vue'

const route = useRoute()
const router = useRouter()

const vehiculosStore = useVehiculosStore()
const appStore = useAppStore()

const vehiculo = ref(null)
const fecha = ref('')
const motivo = ref('')
const error = ref('')

onMounted(async () => {
    await vehiculosStore.cargarDatos()
    vehiculo.value =
        vehiculosStore.getVehiculoById(route.params.id)
})

function reservar() {

    if (!appStore.usuario) {
        router.push('/login')
        return
    }

    const rolUsuario = appStore.usuario.rol

    //  BLOQUEO ESPECÍFICO: vehículo solo directivos
    const esSoloDirectivos =
        !vehiculo.value.acceso.includes('empleado')

    if (esSoloDirectivos && rolUsuario !== 'directivo') {
        error.value = 'Solo directivos pueden reservar este vehículo'
        return
    }

    // ✔️ OK: guardar reserva
    appStore.agregarReserva({
        vehiculo: vehiculo.value,
        fecha: fecha.value,
        motivo: motivo.value
    })

    router.push('/mis-reservas')
}
</script>

<template>
    <div v-if="vehiculo" class="detalle-container">

    <div class="card-vehiculo">

        

        <img :src="`/images/${vehiculo.imagen}`" class="img-detalle">
        <button class="btn-volver" @click="$router.back()">
        ← Volver
        </button>

        <!-- TITULO -->
        <h1 class="titulo">
        {{ vehiculo.marca }} {{ vehiculo.modelo }}
        </h1>

        <!-- DESCRIPCIÓN -->
        <p class="subtitulo">
        {{ vehiculo.descripcion }}
        </p>
        <!-- INFO PRINCIPAL -->
        <div class="badge-row">
        <span class="badge">{{ vehiculo.tipo }}</span>

        <span class="badge" :class="vehiculo.acceso.includes('empleado') ? 'empleado' : 'directivo'">
            {{ vehiculo.acceso.includes('empleado')
            ? 'Acceso empleados'
            : 'Solo directivos'
            }}
        </span>
        </div>

        <!-- ESPECIFICACIONES -->
        <div class="specs">
        <div class="spec">
            <h3>Autonomía</h3>
            <p>{{ vehiculo.autonomia }} km</p>
        </div>

        <div class="spec">
            <h3>Vel. máx</h3>
            <p>{{ vehiculo.velocidadMax }} km/h</p>
        </div>

        <div class="spec">
            <h3>Plazas</h3>
            <p>{{ vehiculo.plazas }}</p>
        </div>
        </div>

        <!-- RESERVA -->
        <div class="acciones">

        <div v-if="appStore.usuario" class="reserva-box">

            <h3>Reservar</h3>

            <input type="date" v-model="fecha">
            <input placeholder="Propósito (reunión, cliente...)" v-model="motivo">

            <button @click="reservar" class="btn-reservar">
            Confirmar reserva
            </button>

        </div>

        <p v-else class="login-msg">
            Debes iniciar sesión para reservar este vehículo

            <RouterLink to="/login" class="btn-login">
            Ir a Login
            </RouterLink>
        </p>

        <p v-if="error" class="error">{{ error }}</p>

        </div>

    </div>

    </div>
</template>
<style setup>
    .btn-login {
    display: inline-block;
    margin-top: 10px;
    padding: 8px 12px;
    background: #1e3c72;
    color: white;
    border-radius: 8px;
    text-decoration: none;
    transition: 0.2s;
    }

    .btn-login:hover {
    background: #2a5298;
    }
    .detalle-container {
    display: flex;
    justify-content: center;
    padding: 30px 10px;
    }

    .card-vehiculo {
    width: 800px;
    
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.1);
    text-align: center;
    position: relative;
    }

    /* TITULOS */
.titulo {
  font-size: 1.8rem;
  margin-top: 10px;
}

.subtitulo {
  color: #666;
  margin-bottom: 15px;
}

/* BADGES */
.badge-row {
  display: flex;
  justify-content: center;
  gap: 10px;
  margin: 15px 0;
}

.badge {
  padding: 5px 12px;
  border-radius: 20px;
  font-size: 0.85rem;
  background: #f0f2ff;
}

/* ESPECIFICACIONES */
.specs {
  display: flex;
  justify-content: space-around;
  margin: 20px 0;
  padding: 15px;
  background: #f7f9ff;
  border-radius: 12px;
}

.spec {
  text-align: center;
}

.spec h3 {
  font-size: 0.9rem;
  color: #666;
  margin-bottom: 5px;
}

.spec p {
  font-size: 1.1rem;
  font-weight: bold;
}

/* ACCIONES */
.acciones {
  margin-top: 20px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

    /* BOTÓN VOLVER */
    .btn-volver {
    position: absolute;
    left: 15px;
    top: 15px;
    background: transparent;
    border: none;
    font-size: 1rem;
    cursor: pointer;
    color: #1e3c72;
    }

    /* IMAGEN */
    .img-detalle {
    width: 100%;
    max-height: 250px;
    object-fit: contain;
    margin: 15px 0;
    }

    /* DESCRIPCIÓN */
    .descripcion {
    color: #555;
    margin-bottom: 15px;
    }

    /* TAGS */
    .info {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-bottom: 20px;
    }

    .tag, .tag-acceso {
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 0.85rem;
    background: #f0f2ff;
    }

    .tag-acceso {
    background: #ffecec;
    }

    /* RESERVA */
    .reserva-box {
    margin-top: 20px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    }

    .reserva-box input {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 8px;
    }

    /* BOTÓN RESERVAR */
    .btn-reservar {
    background: #1e3c72;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: 0.2s;
    }

    .btn-reservar:hover {
    background: #2a5298;
    }

    /* ERROR */
    .error {
    color: red;
    margin-top: 10px;
    }

    /* LOGIN MESSAGE */
    .login-msg {
    margin-top: 15px;
    display: flex;
    flex-direction: column;
    color: #888;
    }
</style>
