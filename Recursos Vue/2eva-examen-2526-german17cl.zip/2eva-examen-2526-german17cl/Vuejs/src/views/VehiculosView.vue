<template>
  <div>
    <h1>Vehículos</h1>

    <div class="filtros">
      <div class="busqueda">
        <label for="">Búsqueda</label>
        <input v-model="filtroTexto" placeholder="Marca o modelo">
      </div>
    
      <div class="tipo">
      <label for="">Tipo</label>
      <select v-model="filtroTipo">
        <option value="">Todos los tipos</option>
        <option v-for="tipo in store.tiposUnicos" :key="tipo">
          {{ tipo }}
        </option>
      </select>
      </div>

      <div class="acceso">
      <label for="">Acceso</label>
      <select v-model="filtroAcceso">
        <option value="todos">Todos</option>
        <option value="empleados">Empleados</option>
      </select>
      </div>
    </div>

    <div class="tabla-vehiculos">
    <div class="fila encabezado">
      <span>Imagen</span>
      <span>Marca / Modelo</span>
      <span>Tipo</span>
      <span>Acceso</span>
      <span>Acción</span>
    </div>

    <div class="fila" v-for="v in vehiculosFiltrados" :key="v.id">
        <img :src="`/images/${v.imagen}`" class="img-vehiculo">

        <span>{{ v.marca }} {{ v.modelo }}</span>

        <span>{{ v.tipo }}</span>

        <span
          class="badge"
          :class="v.acceso.includes('empleado') ? 'empleado' : 'directivo'"
        >
          {{ v.acceso.includes('empleado')
            ? 'Acceso empleados'
            : 'Solo directivos'
          }}
        </span>

        <RouterLink class="btn-detalle" :to="`/vehiculos/${v.id}`">
          Ver detalle
        </RouterLink>
      </div>
    </div>
  </div>
</template>


<script setup>
import { ref, computed, onMounted } from 'vue'
import { useVehiculosStore } from '../stores/useVehiculosStore'
import { RouterLink } from 'vue-router'

const store = useVehiculosStore()

const filtroTexto = ref('')
const filtroTipo = ref('')
const filtroAcceso = ref('todos')

onMounted(() => {
  store.cargarDatos()
})

const vehiculosFiltrados = computed(() => {
  return store.vehiculos.filter(v => {

    const textoOk =
      (v.modelo + v.marca)
        .toLowerCase()
        .includes(filtroTexto.value.toLowerCase())

    const tipoOk =
      !filtroTipo.value || v.tipo === filtroTipo.value

    const accesoOk =
      filtroAcceso.value === 'todos' || (filtroAcceso.value === 'empleados' && v.acceso.includes('empleado'))

    return textoOk && tipoOk && accesoOk
  })
})
</script>


<style scoped>

.badge {
  text-align: center;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 0.85rem;
  font-weight: 500;
  display: inline-block;
  border: 1px solid transparent;
}

/* EMPLEADOS - AZUL SUAVE */
.empleado {
  background: #e6f0ff;
  color: #1e3c72;
  border-color: #b3d1ff;
}

/* DIRECTIVOS - ROJO SUAVE */
.directivo {
  background: #ffe6e6;
  color: #b30000;
  border-color: #ffb3b3;
}

.tabla-vehiculos {
  margin-top: 20px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

/* FILAS */
.fila {
  display: grid;
  grid-template-columns: 120px 1fr 1fr 1fr 140px;
  align-items: center;
  background: white;
  padding: 10px;
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

/* ENCABEZADO */
.encabezado {
  font-weight: bold;
  background: #1e3c72;
  color: white;
}

/* IMAGEN */
.img-vehiculo {
  width: 100px;
  height: auto;
  border-radius: 8px;
  object-fit: cover;
}

/* BOTÓN DETALLE */
.btn-detalle {
  justify-self: end;
  background: #1e3c72;
  color: white;
  padding: 6px 12px;
  border-radius: 6px;
  text-decoration: none;
  font-size: 0.9rem;
  transition: 0.2s;
}

.btn-detalle:hover {
  background: #2a5298;
  transform: scale(1.05);
}

.filtros {
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 12px;
  padding: 15px;
  background: #f5f7ff;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);

  /* clave para que no baje a columnas */
  flex-wrap: nowrap;
}

/* INPUT Y SELECT UNIFICADOS */
.filtros input,
.filtros select {
  padding: 10px 12px;
  border: 1px solid #d0d7ff;
  border-radius: 8px;
  outline: none;
  font-size: 0.95rem;
  background: white;
  transition: 0.2s;
  min-width: 180px;
}

/* FOCUS BONITO */
.filtros input:focus,
.filtros select:focus {
  border-color: #1e3c72;
  box-shadow: 0 0 0 3px rgba(30,60,114,0.15);
}

/* INPUT MÁS GRANDE (búsqueda principal) */
.filtros input {
  flex: 1;
  min-width: 220px;
}

.busqueda{
  display: flex;
  flex-direction: column;
}

.acceso{

  display: flex;
  flex-direction: column;
}

.tipo{

  display: flex;
  flex-direction: column;
}
</style>
