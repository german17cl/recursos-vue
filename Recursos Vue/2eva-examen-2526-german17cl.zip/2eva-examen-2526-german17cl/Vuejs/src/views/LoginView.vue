<script setup>
import { ref } from 'vue'
import axios from 'axios'
import { useRouter } from 'vue-router'
import { useAppStore } from '../stores/useAppStore'

const email = ref('')
const password = ref('')
const error = ref('')

const router = useRouter()
const store = useAppStore()

async function login() {
    error.value = ''

    try {
        const res = await axios.get('/data/usuarios.json')

        const usuario = res.data.find(
            u => u.email === email.value &&
                u.password === password.value
        )

        if (!usuario) {
            error.value = 'Credenciales inválidas'
            return
        }

        store.login(usuario)
        router.push('/')

    } catch (e) {
        error.value = 'Error cargando usuarios'
    }
}
</script>

<template>
    <div class="login-container">

        <div class="login-card">

        <h1>Acceso empleados</h1>

        <input v-model="email" placeholder="Email" class="input">
        <input type="password" v-model="password" placeholder="Password" class="input">

        <button @click="login" class="btn-login">Entrar</button>

        <p v-if="error" class="error">{{ error }}</p>

        </div>

    </div>
</template>

<style setup>

    /* CENTRADO TOTAL */
    .login-container {
    height: 50vh;
    display: flex;
    justify-content: center;
    align-items: center;
        
    }

    /* CARD */
    .login-card {
    background: white;
    padding: 30px;
    border-radius: 16px;
    width: 400px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    text-align: center;
    }

    /* INPUTS */
    .input {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ddd;
    border-radius: 8px;
    outline: none;
    transition: 0.2s;
    }

    .input:focus {
    border-color: #1e3c72;
    box-shadow: 0 0 0 3px rgba(30,60,114,0.15);
    }

    /* BOTÓN */
    .btn-login {
    width: 100%;
    padding: 10px;
    background: #1e3c72;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    margin-top: 10px;
    transition: 0.2s;
    }

    .btn-login:hover {
    background: #2a5298;
    }

    /* ERROR */
    .error {
    color: red;
    margin-top: 10px;
    font-size: 0.9rem;
    }
</style>